package net.sytes.jinda.botum;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.util.Base64;
import android.view.View;
import android.widget.Button;

import net.sytes.jinda.botum.utils.OnEventListener;
import net.sytes.jinda.botum.utils.PostDataThread;
import net.sytes.jinda.botum.utils.PostFileThread;

import java.io.ByteArrayOutputStream;

/**
 * Created by zin on 2017-12-19.
 */

public class FileUploadActivity extends Activity {
    Uri mImageCaptureUri; // 이미지 들어갈 Uri
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fileupload);

        ((Button)findViewById(R.id.btn)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType(MediaStore.Images.Media.CONTENT_TYPE);
                startActivityForResult(intent,1);
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) return;
        switch (requestCode) {
            case 1: {
                mImageCaptureUri = data.getData(); // 갤러리 내 이미지 저장
                Intent intent = new Intent("com.android.camera.action.CROP");
                intent.setDataAndType(mImageCaptureUri, "image/*");

                intent.putExtra("outputX", 200);
                intent.putExtra("outputY", 200);
                intent.putExtra("aspectX", 1);
                intent.putExtra("aspectY", 1);
                intent.putExtra("scale", true);
                intent.putExtra("return-data", true);
                startActivityForResult(intent, 2);
                break;
            } // 휴대폰 내 갤러리 접근
            case 2: {
                if (resultCode != RESULT_OK) return;
                final Bundle extras = data.getExtras();
                if (extras != null) {
                    Bitmap photo = extras.getParcelable("data");
                    int height = photo.getHeight();
                    int width = photo.getWidth();
                    Bitmap resized = null;
                    while (height > 200) {
                        resized = Bitmap.createScaledBitmap(photo, (width * 200) / height, 200, true);
                        height = resized.getHeight();
                        width = resized.getWidth();
                    }
                    if (resized == null) resized = photo;

                    // 비트맵 이미지 문자열로
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    resized.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
                    byte[] b = byteArrayOutputStream.toByteArray();

                    String strImage = Base64.encodeToString(b, Base64.DEFAULT);
                    // System.out.println(strImage);
                    ContentValues cv = new ContentValues();
                    cv.put("imgStr", strImage);
                    PostDataThread postDataThread = new PostDataThread(cv, new OnEventListener() {
                        @Override
                        public void onSuccess(Object object) {}
                        @Override
                        public void onFailure(String s) {}
                    });
                    postDataThread.execute("http://192.168.1.160:8080/BotumProject/upload.do");

                    /*
                    // 문자열 이미지를 비트맵으로
                    byte[] decodedString = Base64.decode(strImage, Base64.URL_SAFE);
                    Bitmap decodeByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                    addImage.setImageBitmap(decodeByte);

                    System.out.println(strImage);


                    PostFileThread postFileThread = new PostFileThread(b, new OnEventListener() {
                        @Override
                        public void onSuccess(Object object) {
                        }
                        @Override
                        public void onFailure(String s) {
                        }
                    }, strImage);
                    postFileThread.execute("http://192.168.1.160:8080/BotumProject/upload.do");
                */

                } // 사진 200x200 으로 crop 후, 비트맵 이미지를 문자열로 encode
                break;
            }
        }
    }
}
