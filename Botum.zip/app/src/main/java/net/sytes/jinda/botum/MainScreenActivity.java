package net.sytes.jinda.botum;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.widget.LinearLayout;

import net.sytes.jinda.botum.objects.ListObject;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Created by zin on 2017-12-19.
 */

public class MainScreenActivity extends Activity {

    LinearLayout linearLayout;
    String[] infoList;
    ListObject object;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainscreen);

        Intent intent = getIntent();
        String jsonStr = intent.getStringExtra("jsonStr");
        linearLayout = (LinearLayout) findViewById(R.id.linearLayout);
        setView(jsonStr);

        infoList = new String[6];
        infoList[0] = "소프트웨어특강2(001)";
        infoList[1] = "201720202922009973001";
        infoList[2] = "광203";
        infoList[3] = "영어강의";
        infoList[4] = "15:00~16:30";
        infoList[5] = "공성곤";
        object = new ListObject(this, infoList);
        linearLayout.addView(object);
    }
    private void setView(String mJsonString) {
        try {
            JSONArray jsonArray = new JSONArray(mJsonString);
            for (int i = 0 ; i < jsonArray.length() ; i ++ ) {
                JSONObject item = jsonArray.getJSONObject(i);
                infoList = new String[6];
                infoList[0] = item.getString("lect_name");
                infoList[1] = item.getString("dir_name");
                infoList[2] = "율203";
                infoList[3] = "일반강의";
                infoList[4] = "09:00~12:00";
                infoList[5] = "안용학";
                object = new ListObject(this, infoList);
                linearLayout.addView(object);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
