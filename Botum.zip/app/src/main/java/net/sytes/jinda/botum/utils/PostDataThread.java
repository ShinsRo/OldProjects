package net.sytes.jinda.botum.utils;

import android.content.ContentValues;
import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

/**
 * Created by zin on 2017-11-13.
 */

public class PostDataThread extends AsyncTask<String, Void, String> { // PostDataThread는 데이터 전송을 쉽게 하기 위한 클래스.
    private ContentValues cv;
    private OnEventListener<String> mCallBack;
    Boolean mException = false;

    public PostDataThread(ContentValues cv, OnEventListener callback) {
        this.cv = cv;
        mCallBack = callback;
    } // 생성자로 콜백함수와 데이터가 들어갈 ContentValue 사용

    @Override
    protected String doInBackground(String... params) {
        String serverURL = params[0];
        System.out.println("server url : "+params[0]);
        try {
            URL url = new URL(serverURL);
            RequestHttpURLConnection requestHttpURLConnection = new RequestHttpURLConnection();
            String result = requestHttpURLConnection.sendRequest(serverURL, cv);
            System.out.println(result);
            if (result.length()>0) { // sql 데이터가 들어가면 서버는 성공이란 문자를 보여줌
                mException = true;
            }
            return result;
        } catch (Exception e) {
            mException = false;
            return null;
        }
    }

    @Override
    protected void onPostExecute(String result) { // doInBackground함수 후 콜백함수 실행
        if (mCallBack != null) {
            if (mException) {
                mCallBack.onSuccess(result);
            } else {
                mCallBack.onFailure(result);
            }
        }
    }
    class RequestHttpURLConnection {

        public String sendRequest(String _url, ContentValues _params){

            // HttpURLConnection 참조 변수.
            HttpURLConnection urlConn = null;

            // URL 뒤에 붙여서 보낼 파라미터. POST로 보낼때만 사용.
            StringBuffer sbParams = new StringBuffer();


            boolean isAnd = false;
            // 파라미터 키와 값.
            String key;
            String value;

            for(Map.Entry<String, Object> parameter : _params.valueSet()){
                key = parameter.getKey();
                value = parameter.getValue().toString();

                // 파라미터가 두개 이상일때, 파라미터 사이에 &를 붙인다.
                if (isAnd)
                    sbParams.append("&");

                sbParams.append(key).append("=").append(value);

                // 파라미터가 2개 이상이면 isAnd를 true로 바꾸고 다음 루프부터 &를 붙인다.
                if (!isAnd)
                    if (_params.size() >= 2)
                        isAnd = true;
            }

            // 연결 시작.
            try{
                URL url = new URL(_url);
                urlConn = (HttpURLConnection) url.openConnection();
                urlConn.setRequestMethod("POST");
                urlConn.connect();

                if(_params != null){
                    OutputStream os = urlConn.getOutputStream();
                    os.write(sbParams.toString().getBytes("UTF-8")); // 출력 스트림에 출력.
                    os.flush(); // 출력 스트림을 플러시(비운다)하고 버퍼링 된 모든 출력 바이트를 강제 실행.
                    os.close(); // 출력 스트림을 닫고 모든 시스템 자원을 해제.
                }

                // 응답 확인
                BufferedReader reader;
                if (urlConn.getResponseCode() != HttpURLConnection.HTTP_OK) {
                    reader = new BufferedReader(new InputStreamReader(urlConn.getErrorStream(),"UTF-8"));
                }
                else{
                    reader = new BufferedReader(new InputStreamReader(urlConn.getInputStream(),"UTF-8"));
                }

                // 출력물의 라인과 그 합에 대한 변수.
                String line;
                String page = "";

                // 라인을 받아와 합친다.
                while ((line = reader.readLine()) != null){
                    page += line + '\n';
                }

                return page;

            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                // 아직 커넥션이 있으면 연결을 끊음.
                if (urlConn != null)
                    urlConn.disconnect();
            }
            return null;
        }
    }
}
