package net.sytes.jinda.botum;

import android.app.Activity;
import android.content.ContentValues;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import net.sytes.jinda.botum.utils.OnEventListener;
import net.sytes.jinda.botum.utils.PostDataThread;

/**
 * Created by zin on 2017-12-19.
 */

public class SignupActivity extends Activity{
    EditText edtTxt1, edtTxt2, edtTxt3;
    String id, pwd, name;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        edtTxt1 = (EditText) findViewById(R.id.editText1);
        edtTxt2 = (EditText) findViewById(R.id.editText2);
        edtTxt3 = (EditText) findViewById(R.id.editText3);

        ((Button)findViewById(R.id.button)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                id = edtTxt1.getText().toString();
                pwd = edtTxt2.getText().toString();
                name = edtTxt3.getText().toString();

                if (id.compareTo(" ") <=0 || pwd.compareTo(" ") <= 0 || name.compareTo(" ") <= 0)
                    Toast.makeText(getApplicationContext(), "위 항목을 전부 채워주시기 바랍니다.", Toast.LENGTH_LONG).show();
                else {
                    ContentValues cv = new ContentValues();
                    cv.put("id", id);
                    cv.put("pwd", pwd);
                    cv.put("name", name);
                    cv.put("is_professor", 1);
                    PostDataThread postDataThread = new PostDataThread(cv, new OnEventListener() {
                        @Override
                        public void onSuccess(Object object) {
                            System.out.println(object.toString());
                        }
                        @Override
                        public void onFailure(String s) {

                        }
                    });
                    postDataThread.execute("url");
                } // if-else
            } // on Click
        }); // Button
    }
}
