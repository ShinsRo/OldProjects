package net.sytes.jinda.botum.utils;

import android.content.ContentValues;
import android.os.AsyncTask;

import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by zin on 2017-12-19.
 */

public class PostFileThread extends AsyncTask<String, Void, String> {
    private byte[] data;
    private OnEventListener<String> mCallBack;
    private String imgStr;
    Boolean mException = false;

    public PostFileThread(byte[] data, OnEventListener callback, String imgStr) {
        this.data = data;
        mCallBack = callback;
        this.imgStr = imgStr;
    } // 생성자로 콜백함수와 데이터가 들어갈 ContentValue 사용

    @Override
    protected String doInBackground(String... params) {
        String serverURL = params[0];
        System.out.println("server url : "+params[0]);
        // doFileUpload(serverURL);

        return null;
    }

    @Override
    protected void onPostExecute(String result) {
        if (mCallBack != null) {
            if (mException) {
                mCallBack.onSuccess(result);
            } else {
                mCallBack.onFailure(result);
            }
        }
    }

    public void doFileUpload(String url) {
        try {
            URL fileUrl = new URL(url);
            String lineEnd = "\r\n";
            String twoHyphens = "--";
            String boundary = "*****";

            HttpURLConnection con = (HttpURLConnection)fileUrl.openConnection();
            con.setDoInput(true);
            con.setDoOutput(true);
            con.setUseCaches(false);
            con.setRequestMethod("POST");
            con.setRequestProperty("Connection", "Keep-Alive");
            con.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);


            DataOutputStream dos = new DataOutputStream(con.getOutputStream());
            dos.writeBytes(lineEnd + boundary + lineEnd);
            // 파일 전송시 파라메터명은 file1 파일명은 camera.jpg로 설정하여 전송
            dos.writeBytes("Content-Disposition: form-data; name=\"scripts\";filename=\"camera.jpg\"" + lineEnd);


            System.out.println("uploaded file : " + data.length);
            System.out.println(data.toString());
            dos.writeBytes(lineEnd);
            dos.write(data,0,data.length);
            dos.writeBytes(lineEnd);
            System.out.println("response : " + con.getResponseCode() + "\nmessage : " + con.getResponseMessage());
            dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);
            dos.flush(); // finish upload...
            dos.close();
        } catch (Exception e) {}
    }

}
