package net.sytes.jinda.botum.objects;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import net.sytes.jinda.botum.R;
import net.sytes.jinda.botum.STTActivity;

/**
 * Created by zin on 2017-12-19.
 */

public class ListObject extends LinearLayout {

    LinearLayout thisLayout;
    String[] infoList;
    TextView txt1, txt2, txt3, txt4, txt5;

    public ListObject(Context context, String[] arr) {
        super(context);
        this.infoList = arr;
        init(context);
    }

    public void init(final Context context) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.object_listview, this, true);

        thisLayout = (LinearLayout) findViewById(R.id.thislayout);
        txt1 = (TextView) findViewById(R.id.txt1);
        txt2 = (TextView) findViewById(R.id.txt2);
        txt3 = (TextView) findViewById(R.id.txt3);
        txt4 = (TextView) findViewById(R.id.txt4);
        txt5 = (TextView) findViewById(R.id.txt5);
        txt1.setText(infoList[0]);
        txt2.setText(infoList[5]);
        txt3.setText(infoList[2]);
        txt4.setText(infoList[3]);
        txt5.setText(infoList[4]);
        thisLayout.setOnClickListener(new OnClickListener() {
            @Override

            public void onClick(View view) {
                Intent intent = new Intent(context.getApplicationContext(), STTActivity.class);
                if (infoList[3].compareTo("영어강의") == 0) {
                    intent.putExtra("language", "en-US");
                } else {
                    intent.putExtra("language", "utf8");
                }
                intent.putExtra("name", infoList[1]);
                intent.putExtra("number", infoList[0]);
                context.startActivity(intent);
            }
        });
    }
}
