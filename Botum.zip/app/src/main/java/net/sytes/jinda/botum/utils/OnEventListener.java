package net.sytes.jinda.botum.utils;

public interface OnEventListener<T> { // 콜백용
    public void onSuccess(T object);
    public void onFailure(String s);
}
