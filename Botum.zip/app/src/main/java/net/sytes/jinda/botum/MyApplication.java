package net.sytes.jinda.botum;

import android.app.Application;

/**
 * Created by zin on 2017-12-19.
 */

public class MyApplication extends Application {
    private String url;
    public String getUrl() {
        return url;
    }
    public void setUrl(String url) {
        this.url = url;
    }
}
