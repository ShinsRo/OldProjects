package net.sytes.jinda.botum;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by zin on 2017-12-19.
 */

public class StartActivity extends AppCompatActivity {

    private Handler handler = new Handler();
    private Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MyApplication myApp = (MyApplication) getApplication();
        myApp.setUrl("http://sejonghacker.iptime.org:8080/BotumProject");

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                intent = new Intent(StartActivity.this, LoginActivity.class);
                // intent = new Intent(StartActivity.this, FileUploadActivity.class);
                startActivity(intent);
                finish();
            }
        }, 2500);
    }
}
