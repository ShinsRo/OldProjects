package net.sytes.jinda.botum;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import net.sytes.jinda.botum.utils.OnEventListener;
import net.sytes.jinda.botum.utils.PostDataThread;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Created by zin on 2017-12-19.
 */

public class LoginActivity extends Activity {
    String url;
    EditText idTxt, pwdTxt;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        url = ((MyApplication) getApplication()).getUrl();
        idTxt = (EditText) findViewById(R.id.main_idTxt);
        pwdTxt = (EditText) findViewById(R.id.main_pwdTxt);

        ((TextView)findViewById(R.id.main_signupBtn)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), SignupActivity.class);
                startActivity(intent);
            }
        });

        ((Button)findViewById(R.id.main_signinBtn)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ContentValues cv = new ContentValues();
                cv.put("id", idTxt.getText().toString());
                cv.put("pw", pwdTxt.getText().toString());
                PostDataThread postDataThread = new PostDataThread(cv, new OnEventListener() {
                    @Override
                    public void onSuccess(Object object) {
                        Intent intent = new Intent( getApplicationContext(), MainScreenActivity.class);
                        intent.putExtra("jsonStr", object.toString());
                        startActivity(intent);
                        finish();
                    }
                    @Override
                    public void onFailure(String s) {
                        Toast.makeText(getApplicationContext(),"아이디와 패스워드를 확인해 주세요",Toast.LENGTH_LONG).show();
                    }
                });
                postDataThread.execute(url + "/getLectureList.do");
            }
        });
    }
}
