package net.sytes.jinda.botum;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import net.sytes.jinda.botum.utils.OnEventListener;
import net.sytes.jinda.botum.utils.PostDataThread;

import java.io.DataOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;


/**
 * Created by zin on 2017-12-17.
 */

public class STTActivity extends Activity {
    Intent i;
    SpeechRecognizer mRecognizer;
    TextView textView;
    String url, name, number;
    ImageView imageView;
    Boolean isRun = false;
    ContentValues cv;

    @Override
    protected void onDestroy() {
        AudioManager amanager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        amanager.setStreamMute(AudioManager.STREAM_NOTIFICATION, false);
        amanager.setStreamMute(AudioManager.STREAM_ALARM, false);
        amanager.setStreamMute(AudioManager.STREAM_MUSIC, false);
        amanager.setStreamMute(AudioManager.STREAM_RING, false);
        amanager.setStreamMute(AudioManager.STREAM_SYSTEM, false);
        super.onDestroy();
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stt);

        permission();

        Intent intent = getIntent();
        String language = intent.getStringExtra("language");
        name = intent.getStringExtra("name");
        number = intent.getStringExtra("number");
        textView = (TextView) findViewById(R.id.textView);
        imageView = (ImageView) findViewById(R.id.btn);
        cv = new ContentValues();

        url = ((MyApplication) getApplication()).getUrl();

        i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, language);

        mRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        mRecognizer.setRecognitionListener(listener);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isRun) {
                    // mRecognizer.stopListening();
                    mRecognizer.cancel();
                    imageView.setImageResource(R.drawable.asset2);
                    isRun = !isRun;
                    cv.put("msg", "/1");
                    cv.put("fileName", name);
                    cv.put("dir", number);
                    PostDataThread postDataThread = new PostDataThread(cv, new OnEventListener() {
                        @Override
                        public void onSuccess(Object object) {}
                        @Override
                        public void onFailure(String s) {}
                    });
                    postDataThread.execute(url + "/recode.do");
                } else {
                    mRecognizer.startListening(i);
                    imageView.setImageResource(R.drawable.asset3);
                    isRun = !isRun;
                    cv.put("msg", "/0");
                    cv.put("fileName", name);
                    cv.put("dir", number);
                    PostDataThread postDataThread = new PostDataThread(cv, new OnEventListener() {
                        @Override
                        public void onSuccess(Object object) {}
                        @Override
                        public void onFailure(String s) {}
                    });
                    postDataThread.execute(url + "/recode.do");
                }
            }
        });

        AudioManager amanager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        amanager.setStreamMute(AudioManager.STREAM_NOTIFICATION, true);
        amanager.setStreamMute(AudioManager.STREAM_ALARM, true);
        amanager.setStreamMute(AudioManager.STREAM_MUSIC, true);
        amanager.setStreamMute(AudioManager.STREAM_RING, true);
        amanager.setStreamMute(AudioManager.STREAM_SYSTEM, true);
        // amanager.setMicrophoneMute(false);
    }
    private RecognitionListener listener = new RecognitionListener() {

        @Override
        public void onReadyForSpeech(Bundle params) {
            System.out.println("onReadyForSpeech");
        }
        @Override
        public void onBeginningOfSpeech() {
            System.out.println("onBeginningOfSpeech");
        }

        @Override
        public void onRmsChanged(float rmsdB) {
            System.out.println("onRmsChanged");
        }

        @Override
        public void onBufferReceived(byte[] buffer) {
        }

        @Override
        public void onEndOfSpeech() {
            System.out.println("onEndOfSpeech");
        }

        @Override
        public void onError(int error) {
            System.out.println("Error : " + error);
            mRecognizer.startListening(i);
        }

        @Override
        public void onResults(Bundle results) {
            ///
            String key= "";
            key = SpeechRecognizer.RESULTS_RECOGNITION;
            ArrayList<String> mResult = results.getStringArrayList(key);

            String[] rs = new String[mResult.size()];
            mResult.toArray(rs);

            textView.setText("" + rs[0]);

            cv.put("msg", rs[0]);
            cv.put("fileName", name);
            cv.put("dir", number);
            PostDataThread postDataThread = new PostDataThread(cv, new OnEventListener() {
                @Override
                public void onSuccess(Object object) {}
                @Override
                public void onFailure(String s) {}
            });
            postDataThread.execute(url + "/recode.do");
            mRecognizer.startListening(i);
        }

        @Override
        public void onPartialResults(Bundle partialResults) {
        }

        @Override
        public void onEvent(int eventType, Bundle params) {
        }
    };
    public void permission() {
        int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO);
        if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Recorder 수신 권한 있음." , Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "Recorder 수신 권한 없음." , Toast.LENGTH_LONG).show();
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.RECORD_AUDIO)) {
                Toast.makeText(this, "Recorder 권한 설명 필요함." , Toast.LENGTH_LONG).show();
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, 1);
                // 사용자가 볼 수 있도록 새로운 권한 부여 요청 대화 상자를 띄움
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch(requestCode) {
            case 1: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Recorder 권한을 사용자가 승인함." , Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this, "Recorder 권한 거부됨" , Toast.LENGTH_LONG).show();
                }
                return ;
            }
        }
    }

}
